getCorrData<-function(normInt){
return(normInt@corrInfo@corrData)
}
