medians <- function(input,plot=TRUE,log=TRUE){

  if(length(input@rawInfo@outliers)!=0){
dataMatrix <- input@rawInfo@data
}else{
  dataMatrix <- input@rawInfo@rawData
}


  
classes <- input@rawInfo@classes

  if(log==TRUE){
    dataMatrix <- log10(dataMatrix+1)

}

  
meanDat <- rowMedians(dataMatrix)

  dataMatrix <- dataMatrix[which(meanDat!=0),]
  meanDat <- meanDat[which(meanDat!=0)]

#foldChange <- (apply(X=(dataMatrix),MARGIN=2,FUN=foldchange,denom=meanDat))

   n <- dataMatrix/meanDat

  nmed <- apply(X=n,2,median)

  
#data <- log(t(t(dataMatrix)/nmed),base=2)

data <- t(t(dataMatrix)/nmed)

  
if(plot){
model<-prcomp((t(data)),scale=TRUE,center=TRUE)
dev.new()
  plot(model$x[,1],model$x[,2],col=as.factor(classes),pch=16)
}

out <- list(data,n)
  names(out) <- c("data","n")
  
return(out)
  
}

