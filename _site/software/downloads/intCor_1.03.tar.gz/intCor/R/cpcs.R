cpcs <- function(input,modClasses,log=TRUE,nComps=1,plot=TRUE){

  if(length(input@rawInfo@outliers)!=0){
dataMatrix <- input@rawInfo@data
}else{
  dataMatrix <- input@rawInfo@rawData
}
classes <- input@rawInfo@classes

cat("Detected available classes to select for correction:",fill=TRUE)
show(summary(as.factor(classes)))
cat("Selected classes to compute the drift model:",fill=TRUE)
show(modClasses)

#Logarithmic scale?
if(log){
X <- log10(t(dataMatrix+1)[classes %in% modClasses,])
}else{
X <- t(dataMatrix)[classes %in% modClasses,]
}


Y <- factor(classes[classes %in% modClasses])
ngr <- nlevels(factor(Y)) # number of groups (classes)

X <- scale(X, center = TRUE, scale = TRUE) # See `attributes(X)`
rownames(X) <- NULL
colnames(X) <- NULL
# `C` Crix of correlations
C <- daply(data.frame(X, Y), "Y", function(x) cov(x[, -ncol(x)]))

C <- aperm(C, c(2, 3, 1)) # put the 1st dimension to the end

cat(fill=TRUE)
cat("Computing CPC model...")
if(nComps<=3){
cpcs <- cpc(C, k = 3) # Compute nComps CPC components
}else{
cpcs <- cpc(C, k = nComps) # Compute nComps CPC components
}
cat("Model done!",fill=TRUE)

out<-cpcs$CPC
cat(fill=TRUE)
cat("Computing CPC explained variance...",fill=TRUE)

rownames(out) <- colnames(X)
colnames(out) <- paste("CPC", 1:ncol(out), sep = "")

var.projected <- apply(out, 2, function(e) sum((X %*% e)^2))
var.total <- sum(apply(X, 2, function(x) sum((x)^2)))


var.cpc <- var.projected / var.total
var.cpc <- round(var.cpc,3)[c(1:nComps)]

show(var.cpc)

if(plot){
dev.new()
M <- prcomp(X)
T <- M$x
P <- M$rotation


# 2: Projct eigenvectors in `E` onto the space of `M` model
Et <- t(out) %*% P # `E` in space of model `M`, i.e. scores of `E`

# select just first two CPC
Et <- Et[1:2, ]

#p2 <- qplot(PC1, PC2, data = as.data.frame(T), color = Y) +
#  geom_segment(data = as.data.frame(Et), aes(x = 0, xend = PC1, 
#    y = 0, yend = PC2, color = rownames(Et)), arrow = arrow(length=unit(0.25, "inches")))
#plot(p2,main="CPC directions")

dataMatrix <- scale(log10(t(dataMatrix+1)),scale=TRUE,center=TRUE)

out<-cpcs$CPC[,1:nComps]

corr <- (dataMatrix %*%out)%*%t(out)
corrsc <- corr
for (i in c(1:dim(dataMatrix)[2])){
corrsc[,i] <- (corr[,i]*attributes(dataMatrix)$`scaled:scale`[i])+attributes(dataMatrix)$`scaled:center`[i]
}
dev.new()
heatmap.2(corrsc,trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",xlab="Retention Time (min)",ylab="Sample",col=rev(grey(0:15/15)),main="Data Correction")

}
out<-cpcs$CPC[,1:nComps]



  
if(is.null(dim(out))){out <- (as.matrix(out,ncol=1))}
output<-list(out,var.cpc)
names(output) <- c("out","variance")
return(output)
}
