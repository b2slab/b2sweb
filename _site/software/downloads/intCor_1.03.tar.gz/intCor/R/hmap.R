hmap <- function(object){
          if(!((dim(object@rawInfo@rawData)[1]==1)&&(sum(is.na(object@rawInfo@rawData))==1))){
            dev.new()
            frame()
#            data<-log10(object@rawInfo@rawData)[,rev(1:(dim(object@rawInfo@rawData)[2]))]
            if(length(object@rawInfo@outliers)!=0){
                data <- t(log10(object@rawInfo@data+1))
            }else{
                data <- t(log10(object@rawInfo@rawData+1))
            }

#            gplots::heatmap.2(x=data,trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",main="Raw Signal",xlab="rt")
            #image(data,axes=F,xlab="Retention Time",ylab="Samples",main="Raw Data (Log Scale)")
#axis(side=1,at=round(round(as.numeric(rownames(object@rawInfo@rawData)),2)/max(round(as.numeric(rownames(object@rawInfo@rawData)),2)),3),labels=round(as.numeric(rownames(object@rawInfo@rawData)),3),las=2,cex.axis=0.6,lwd=0)
#axis(side=2,at=(1:length(colnames(object@rawInfo@rawData)))/length(colnames(object@rawInfo@rawData)),labels=colnames(object@rawInfo@rawData),las=2,cex.axis=0.6,lwd=0)
            hraw <- heatmap.2(main="Raw Signal (log scale)",x=data,trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",col=rev(grey(0:15/15)),xlab="Retention Time (min)",ylab="Sample")

          }
          
          if(!((dim(object@corrInfo@corrData)[1]==1)&&(sum(is.na(object@corrInfo@corrData))==1))){
            dev.new()
              data<-t(log10(object@corrInfo@corrData+1))

            heatmap.2(main="Corrected Signal (log scale)",x=data,trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",xlab="Retention Time (min)",ylab="Sample",breaks=hraw$breaks,col=hraw$col)

          }

          }
