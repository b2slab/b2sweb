setMethod(f="show",signature="normInt",
          function(object) {
            if(length(object@rawInfo@classes)>0){
              if(object@rawInfo@featureType=="time"){
             cat(paste("normInt object with a retention time range of [", object@rawInfo@scanRange[1],",",object@rawInfo@scanRange[2],"] seconds containing:",sep=""),fill=TRUE)}
         if(object@rawInfo@featureType=="mass"|object@rawInfo@featureType=="mass"){
             cat(paste("normInt object with a mass range of [", round(object@rawInfo@scanRange[1],3),",",round(object@rawInfo@scanRange[2],3),"] Da containing:",sep=""),fill=TRUE)}
              
                  for(i in c(1:length(unique(object@rawInfo@classes)))){
                          cat(paste(sum(object@rawInfo@classes%in%unique(object@rawInfo@classes)[i]),"samples of the class",unique(object@rawInfo@classes)[i],sep=" "),fill=TRUE)
                        }
                }

            if(length(object@corrInfo@corrMethod)>0){

               cat(fill=TRUE)
                cat(paste("The data was normalised using the",object@corrInfo@corrMethod,"method",sep=" "),fill=TRUE)
                  
           }else{
                 cat("The data has not been normalised",fill=TRUE)
                  }
            })
          

setMethod(f="summary",signature="normInt",
          function(object) {
            if(length(object@rawInfo@classes)>0){
             cat(paste("normInt object with retention a time range of [", object@rawInfo@scanRange[1],",",object@rawInfo@scanRange[2],"] seconds containing:",sep=""),fill=TRUE)
                  for(i in c(1:length(unique(object@rawInfo@classes)))){
                          cat(paste(sum(object@rawInfo@classes%in%unique(object@rawInfo@classes)[i]),"samples of the class",unique(object@rawInfo@classes)[i],sep=" "),fill=TRUE)
                        }
                }
                if(length(object@rawInfo@outliers)!=0){
                  cat(fill=TRUE)
                cat("There were removed the following outliers:",fill=TRUE)
                  for(i in c(1:length(unique(object@rawInfo@classes)))){
                     if(length(object@rawInfo@outliers[[i]])>0){
                       cat(paste(length(object@rawInfo@outliers[[i]]),"samples of class",unique(object@rawInfo@classes)[i],sep=" "),fill=TRUE)
                     }
                   }
              }

            if(length(object@corrInfo@corrMethod)>0){

               cat(fill=TRUE)
                cat(paste("The data was normalised using the",object@corrInfo@corrMethod,"method",sep=" "),fill=TRUE)
                cat("The variance captured for each component was",fill=TRUE)
               for(i in c(1:length(object@corrInfo@explVariance))){
                 cat(paste(object@corrInfo@explVariance[i],"for component",i,sep=" "),fill=TRUE)
               }

                       cat("",fill=TRUE)
            cat("The computed Dunn indices before and after the normalisation:",fill=TRUE)   
        cat("Raw Dunn index = ",object@rawInfo@dunn,fill=TRUE)
  cat("Corrected Dunn index = ",object@corrInfo@dunn,fill=TRUE)
                       cat("",fill=TRUE)
            cat("The computed Silhouette indices before and after the normalisation:",fill=TRUE)   
        cat("Raw Silhouette index = ",object@rawInfo@silhouette,fill=TRUE)
  cat("Corrected Silhouette index = ",object@corrInfo@silhouette,fill=TRUE)

               
           }else{
                 cat("The data has not been normalised",fill=TRUE)
                  }
            })
          
