printCDFfile <- function(dataDir,file,scanRange=NULL,dataMatrix,dir2print,fileType,log){
  
  dataDir <- unlist(strsplit(dataDir,"/"))
  files <- list.files(dataDir,recursive=TRUE,full.names=TRUE)
  fileNamesExt <- unlist(strsplit(files,"/"))[seq(from=3,to=length(unlist(strsplit(files,"/"))),by=3)]
  fileNames <- unlist(strsplit(fileNamesExt,paste(".",fileType,sep="")))
  if(length(grep(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],files))==1){
    filePath <- files[grep(file,files)]

    data <- dataMatrix[,grep(pattern=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],colnames(dataMatrix))]
}
  if(length(grep(file,files))>1){
    filePath <- files[match(file,unlist(strsplit(colnames(dataMatrix),paste(".",fileType,sep=""))))]
    data <- dataMatrix[,match(file,unlist(strsplit(colnames(dataMatrix),paste(".",fileType,sep=""))))]
  }

#    scanRange=round(as.numeric(names(data))[c(1,length(data))]*60)
  if(!is.null(scanRange)){
     sampleXcms<-xcmsRaw(filePath,scanrange=scanRange)
}else{
       sampleXcms<-xcmsRaw(filePath)
   }
#     sampleXcms@tic<-data
#     sampleXcms@scantime <- as.numeric(names(data))*60

if(log){
  data <- 10^data
}
  
    sampleXcms@tic <- aspline(x=as.numeric(names(data))*60,y=data,xout=sampleXcms@scantime)$y

dir <- unlist(strsplit(files[grep(pattern=file,files)],split=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))]))

  path <- paste(getwd(),dir2print,paste(unlist(strsplit(files[grep(pattern=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],x=paste(fileNames,fileType,sep="."))],paste(".",fileType,sep=""))),"cdf",sep="."),sep="/")
  
  if(!file.exists(unlist(strsplit(path,strsplit(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],fileType)))[1])){
    dir.create(unlist(strsplit(path,strsplit(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],fileType)))[1])}
write.cdf(file=path,sampleXcms)

  
   }
