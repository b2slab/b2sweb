cc <- function(input,modClasses,log=TRUE,nComps=1,plot=TRUE){

  if(length(input@rawInfo@outliers)!=0){
dataMatrix <- input@rawInfo@data
}else{
  dataMatrix <- input@rawInfo@rawData
}


classes <- input@rawInfo@classes

cat("Detected available classes to select for correction:",fill=TRUE)
show(summary(as.factor(classes)))
cat("Selected classes to compute the drift model:",fill=TRUE)
show(modClasses)

#Logarithmic scale?
if(log){
X <- log10(t(dataMatrix+1)[classes %in% modClasses,])
}else{
X <- t(dataMatrix)[classes %in% modClasses,]
}
Y <- as.numeric(factor(classes[classes %in% modClasses]))
cat(fill=TRUE)
cat("Computing Component Correction Model...")

#mod <- prcomp(X,scale=TRUE,center=TRUE)
mod <- pca(X,scale="uv",center=TRUE,nPcs=nComps)
#out<-mod$rotation[,1:nComps]
  out <- loadings(mod)[,1:nComps]
cat("done!",fill=TRUE)

cat(fill=TRUE)
cat("Computing CC Model explained variance...",fill=TRUE)

#rownames(out) <- colnames(X)
#colnames(out) <- paste("CPC", 1:ncol(out), sep = "")


#var.art <- summary(mod)$importance[2,1:nComps]

var.art <- mod@R2


show(round(var.art,3))

if(plot){
  dev.new()
#plot(mod$x[,1],mod$x[,2],col=Y,xlab=paste("PC1 (",round(summary(mod)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(mod)$importance[2,2]*100,1),"%)",sep=""),cex=0.8,pch=16,main="PCA scoreplot of the chosen classes")
  if(nComps>1){
 plot(scores(mod)[,1],scores(mod)[,2],col=Y,xlab=paste("PC1 (",round(var.art[1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(var.art[2]*100,2),"%)",sep=""),cex=0.8,pch=16,main="PCA scoreplot of the chosen classes")
}else{
   plot(scores(mod)[,1],col=Y,ylab=paste("PC1 (",round(var.art[1]*100,1),"%)",sep=""),cex=0.8,pch=16,main="PCA scoreplot of the selected classes")
 }
 legend("topright",pch=16,legend=modClasses,col=as.numeric(as.factor(modClasses)),bg=grey(0.9))
}

if(is.null(dim(out))){out <- (as.matrix(out,ncol=1))}


dataMatrix <- scale(log10(t(dataMatrix+1)),scale=TRUE,center=TRUE)

  
corr <- (dataMatrix %*%out)%*%t(out)
corrsc <- corr
for (i in c(1:dim(dataMatrix)[2])){
corrsc[,i] <- (corr[,i]*attributes(dataMatrix)$`scaled:scale`[i])+attributes(dataMatrix)$`scaled:center`[i]
}
  dev.new()

  if(input@rawInfo@featureType=="time"){
  
heatmap.2(corrsc,trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",xlab="Retention Time (min)",ylab="Sample",col=rev(grey(0:15/15)),main="Data Correction")

}else{

  heatmap.2(corrsc,trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",xlab="Masses (m/z)",ylab="Sample",col=rev(grey(0:15/15)),main="Data Correction")
  
}

  
output<-list(out,var.art)
names(output) <- c("out","variance")
return(output)
}
