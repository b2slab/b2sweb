cpcaMed <- function(normInt,modClasses,log=TRUE,nComps=1,plot=TRUE){

    normInt@corrInfo@corrMethod <- "cpcaMed"
    normInt@corrInfo@modClasses <- modClasses
    normInt@corrInfo@nComps <- nComps
    aux <- cpcs(input=normInt,modClasses=modClasses,log=log,nComps=nComps,plot=plot)
    normInt@corrInfo@corrModel <- aux$out
    normInt@corrInfo@explVariance <- aux$variance

      if(length(normInt@rawInfo@outliers)!=0){
data <- normInt@rawInfo@data
}else{
  data <- normInt@rawInfo@rawData
}


  if(log==TRUE){
  dat <- scale(log10(t(data+1)),center=TRUE,scale=TRUE)
}else{
  dat <- scale(t(data),center=TRUE,scale=TRUE)
}

cat("Correcting Intensity Drift...")
  
Xc <- dat-((dat %*% normInt@corrInfo@corrModel)%*%t(normInt@corrInfo@corrModel))
   XcRes <- Xc
   for (i in c(1:dim(dat)[2])){
      XcRes[,i] <- (Xc[,i]*attributes(dat)$`scaled:scale`[i])+attributes(dat)$`scaled:center`[i]
   }
   Xc <- XcRes



dataMatrix <- 10^t(Xc)


    
meanDat <- rowMedians(dataMatrix)

#foldChange <- (apply(X=(dataMatrix),MARGIN=2,FUN=foldchange,denom=meanDat))

   n <- dataMatrix/meanDat

  nmed <- apply(X=n,2,median)

  
#data <- log(t(t(dataMatrix)/nmed),base=2)
  
data <- t(t(dataMatrix)/nmed)

normInt@corrInfo@corrData <- data

    data <- normalize.medFC(dataMatrix)
    
if(plot){
  classes <- normInt@rawInfo@classes
 model<-prcomp(log10(t(data)),scale=TRUE)
  plot(model$x[,1],model$x[,2],col=as.numeric(as.factor(normInt@rawInfo@classes)),pch=16,cex=0.8,main="Corrected Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Classes")
legend("topright",pch=16,col=1:length(levels(as.factor(normInt@rawInfo@classes))),legend=levels(as.factor(normInt@rawInfo@classes)),bg=grey(0.9))

}

    
    return(normInt)

  }


normalize.medFC <- function(mat) {
   # Perform median fold change normalisation
   #           X - data set [Variables & Samples]
   medSam <- apply(mat, 1, median)
   medSam[which(medSam==0)] <- 0.0001
   mat2 <- apply(mat, 2, function(mat, medSam){
      medFDiSmpl <- mat/medSam
      vec<-mat/median(medFDiSmpl)
      return(vec)
   }, medSam)
   return (mat2)
}
