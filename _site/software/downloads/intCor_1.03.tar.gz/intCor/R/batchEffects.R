batchEffects <- function(input,log=TRUE,plot=TRUE){

  if(length(input@rawInfo@outliers)!=0){
dataMatrix <- input@rawInfo@data
}else{
  dataMatrix <- input@rawInfo@rawData
}
  if(log){dataMatrix <- log10(dataMatrix+1)}
classes <- input@rawInfo@classes

d<-data.frame(as.factor(input@rawInfo@column),input@rawInfo@batch,input@rawInfo@time,as.factor(input@rawInfo@classes))
colnames(d) <- c("column","batch","time","classes")

 cat("Defining Model Matrix",fill=TRUE)
m<-model.matrix(~as.factor(classes),data=d)
 cat("Correcting Batch effects...",fill=FALSE)
 # colnames(dataMatrix) <- NULL
corrData = ComBat(dat=dataMatrix, batch=d$batch, mod=m, par.prior=TRUE, prior.plots=FALSE)
colnames(corrData)<-colnames(dataMatrix)
 cat("Done",fill=TRUE)
  if(log&(min(corrData)<=0)){
    corrData<-corrData+abs(min(corrData))+1
  }

  cat("Computing explained variance...",fill=TRUE)
var.cpc <- 1-sum((dataMatrix-corrData)^2)/sum((dataMatrix)^2)
  var.cpc <- round(var.cpc,3)
 show(var.cpc)
output<-list(corrData,var.cpc)
names(output) <- c("out","variance")
return(output)
}
