cdfFileCreator <- function(dataMatrix=NULL,dir2print=NULL,scanRange=NULL,dataDir,fileType="mzXML",log){
  if(is.null(dir2print)){stop("No destination directory was set")}
  if(is.null(dataMatrix)){stop("No dataMatrix was set")}
if(!file.exists(paste(getwd(),dir2print,sep="/"))){dir.create(paste(getwd(),dir2print,sep="/"))}
if(!file.exists(paste(getwd(),dir2print,dataDir,sep="/"))){dir.create(paste(getwd(),dir2print,dataDir,sep="/"))}
#if(is.null(scanRange)){
  #scanRange=as.numeric(rownames(dataMatrix))[c(1,dim(dataMatrix)[1])]
#}
if(length(grep("mzXML",colnames(dataMatrix)))>0){
files <- unlist(strsplit(colnames(dataMatrix),".mzXML"))
}else{
files <- colnames(dataMatrix)
}
lapply(X=files,dataDir=dataDir,scanRange=scanRange,dataMatrix=dataMatrix,FUN=printCDFfile,dir2print=dir2print,fileType=fileType,log=log)
}

