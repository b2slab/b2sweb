corrModel<-function(normInt,method,modClasses=NULL,log=TRUE,nComps=1,plot=TRUE,printCDF=FALSE,dir2print="correctedCDFs"){
  
  normInt@corrInfo@log <- log
  
  if(method=="cpca"){
    normInt@corrInfo@corrMethod <- "cpca"
    normInt@corrInfo@modClasses <- modClasses
    normInt@corrInfo@nComps <- nComps
    aux <- cpcs(input=normInt,modClasses=modClasses,log=log,nComps=nComps,plot=plot)
    normInt@corrInfo@corrModel <- aux$out
    normInt@corrInfo@explVariance <- aux$variance
    normInt <- correction(normInt=normInt,printCDF=printCDF,plot=plot)
  }

  if(method=="cpcaMed"){
    normInt <- cpcaMed(normInt=normInt,modClasses=modClasses,log=log,nComps=nComps,plot=plot)
  }

    if(method=="medCpca"){


    normInt@corrInfo@corrMethod <- "medians"
    aux <- medians(input=normInt,plot=plot,log=log)
    normInt@corrInfo@corrModel <- aux$n
    normInt@corrInfo@corrData <- aux$data

    normInt@corrInfo@corrMethod <- "medCpca"
    normInt@corrInfo@modClasses <- modClasses
    normInt@corrInfo@nComps <- nComps
    aux <- cpcs(input=normInt,modClasses=modClasses,log=log,nComps=nComps,plot=plot)
    normInt@corrInfo@corrModel <- aux$out
    normInt@corrInfo@explVariance <- aux$variance
    normInt <- correction(normInt=normInt,printCDF=printCDF,plot=plot)
    
      
  }

  
    if(method=="cc"){
    normInt@corrInfo@corrMethod <- "cc"
    normInt@corrInfo@modClasses <- modClasses
    normInt@corrInfo@nComps <- nComps
    aux <- cc(input=normInt,modClasses=modClasses,log=log,nComps=nComps,plot=plot)
    normInt@corrInfo@corrModel <- aux$out
    normInt@corrInfo@explVariance <- aux$variance
    normInt <- correction(normInt=normInt,printCDF=printCDF,plot=plot)
  }

      if(method=="medians"){
    normInt@corrInfo@corrMethod <- "medians"
    aux <- medians(input=normInt,plot=plot)
    normInt@corrInfo@corrModel <- aux$n
    normInt@corrInfo@corrData <- aux$data
  }


      if(method=="batch"){
    normInt@corrInfo@corrMethod <- "batch"
#    normInt@corrInfo@modClasses <- modClasses
#    normInt@corrInfo@nComps <- nComps
    aux <- batchEffects(input=normInt,log=log,plot=plot)
    normInt@corrInfo@corrData <- aux$out
    normInt@corrInfo@explVariance <- aux$variance
  }

if(method=="medians"|method=="batch"|method=="cpcaMed"){
  
  if(length(normInt@rawInfo@outliers)!=0){
data <- normInt@rawInfo@data
}else{
  data <- normInt@rawInfo@rawData
}
    classes <- normInt@rawInfo@classes
    Xc <- normInt@corrInfo@corrData

    

Xc<-(normInt@corrInfo@corrData)
data <- t(scale(log10(t(data+1)),center=TRUE,scale=TRUE))
  Xc <- t(scale(log10(t(Xc-min(Xc)+1)),center=TRUE,scale=TRUE))

  cat("",fill=TRUE)
  cat("Computing clustering indices ... ",fill=TRUE)

    rawMod <- prcomp(t(data))
    corrMod <- prcomp(t(Xc))

#clMeasuresRaw <- clValid(rawMod$x[!classes=="sample",1:2], 3, clMethods="kmeans",validation="internal")@measures
#clMeasuresCorr <- clValid(corrMod$x[!classes=="sample",1:2], 3, clMethods="kmeans",validation="internal")@measures

  if(!is.null(modClasses)){
clMeasuresRaw <- clValid(rawMod$x[classes%in%modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures
clMeasuresCorr <- clValid(corrMod$x[classes%in%modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures
}else{
clMeasuresRaw <- clValid(rawMod$x[,1:2], 3, clMethods="kmeans",validation="internal")@measures
clMeasuresCorr <- clValid(corrMod$x[,1:2], 3, clMethods="kmeans",validation="internal")@measures
}


  
internRawDunn <- as.numeric(clMeasuresRaw)[2]
internCorrDunn <- as.numeric(clMeasuresCorr)[2]
internRawSilh <- as.numeric(clMeasuresRaw)[3]
internCorrSilh <- as.numeric(clMeasuresCorr)[3]

normInt@rawInfo@dunn <- internRawDunn
normInt@corrInfo@dunn <- internCorrDunn
normInt@rawInfo@silhouette <- internRawSilh
normInt@corrInfo@silhouette <- internCorrSilh

    cat("Raw Data",fill=TRUE)
 show(clValid(rawMod$x[!classes=="sample",1:2], 3, clMethods=c("kmeans","hierarchical"),validation="internal")@measures)
    cat("Corrected Data",fill=TRUE)
 show(clValid(corrMod$x[!classes=="sample",1:2], 3, clMethods=c("kmeans","hierarchical"),validation="internal")@measures)


  
if(plot){
model<-prcomp(log10(t(normInt@corrInfo@corrData+1)),scale=TRUE)
dev.new()
plot(model$x[,1],model$x[,2],col=as.numeric(as.factor(normInt@rawInfo@classes)),pch=16,cex=0.8,main="Corrected Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Classes")
legend("topright",pch=16,col=1:length(levels(as.factor(normInt@rawInfo@classes))),legend=levels(as.factor(normInt@rawInfo@classes)),bg=grey(0.9))
}

    
    
  }

  
  return(normInt)
}
#  test <- function(x,par){return(anova(lm(x~par))$Pr[1])}
