importData <- function(data=NULL,dataDir=NULL,classes=NULL,time=NULL,batch=NULL,column=NULL,scanRange=NULL,colNames=NULL,tabName=NULL,fileType="mzXML",removeOutliers=TRUE,peakInSamples=0.5,automaticOutlierRemoval=FALSE){

if(is.null(data)&is.null(dataDir)){
  stop("No data matrix or data directory was given")
}

if(!is.null(data)&!is.null(dataDir)){
  stop("data and dataDir arguments were both set. Please, give just one of the arguments.")
}

if(!is.null(data)&class(data)!="xcmsSet"&is.null(classes)){
  stop("The data argument was set but a classes vector is needed.")
}

if(is(data,"xcmsSet")){
  dataLabel <- "mass"
if(is.null(classes)){
classes <- as.character(phenoData(data)$class)
}
classLabels <- unique(classes)
}

if(!is.null(dataDir)&is.null(classes)&is.null(tabName)){
  classes <- unlist(strsplit(list.files(dataDir,recursive=T),"/"))[seq(from=1,to=length(unlist(strsplit(list.files(dataDir,recursive=T),"/"))),by=2)]
classLabels <- unique(classes)
}
  
output <- new("normInt")
  


if(!is.null(dataDir)){
  dataDir <- unlist(strsplit(dataDir,"/"))
  files <- list.files(dataDir,recursive=TRUE,full.names=TRUE)
#perc <- 50
#files <- c(sample(list.files("dataPatronReduitAlignedRand10/refe/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedRand10/refe/"))*perc/100)),
#sample(list.files("dataPatronReduitAlignedRand10/sampl/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedRand10/sampl/"))*perc/100)),
#sample(list.files("dataPatronReduitAlignedRand10/agua/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedRand10/agua/"))*perc/100)),
#sample(list.files("dataPatronReduitAlignedRand10/QC/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedRand10/QC/"))*perc/100)))

 # files <- c(sample(list.files("dataPatronReduitAlignedAll/refe/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedAll/refe/"))*perc/100)),
#sample(list.files("dataPatronReduitAlignedAll/sampl/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedAll/sampl/"))*perc/100)),
#sample(list.files("dataPatronReduitAlignedAll/agua/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedAll/agua/"))*perc/100)),
#sample(list.files("dataPatronReduitAlignedAll/qc/",full.names=TRUE),round(length(list.files("dataPatronReduitAlignedAll/qc/"))*perc/100)))

if(!is.null(dataDir)){
  s<-function(x){return(x[length(x)])}
fileNames <- sapply(X=strsplit(files,"/"),FUN=s)
}
  
  if(!is.null(tabName)){
    cat("Reading input table...",fill=FALSE)
tab <- read.csv2(tabName,sep=",")
if(is.null(tab$Class)&is.null(classes)){warning("No class information was provided. Only non-class related methods can be applied (medians, batch).")}

#s<-function(x){return(x[length(x)])}
#fileNames <- sapply(X=strsplit(files,"/"),FUN=s)
#tab <- tab[paste(paste(tab[,2],tab[,5],sep="-"),fileType,sep=".")%in%fileNames,]
tab <- tab[paste(tab$FileName,fileType,sep=".")%in%fileNames,]

index <- vector(length=dim(tab)[1])
    
    for (i in c(1:dim(tab)[1])){
    index[i] <- grep(paste(tab$FileName,fileType,sep=".")[i],files)
    }

    
files <- files[index]
fileNamesOrd <- sapply(X=strsplit(files,"/"),FUN=s)
    
if(!is.null(tab$Class)){
classes <- as.character(tab$Class)
}


    
classLabels <- unique(classes)
if(!is.null(tab$Batch)){
#batch <- as.factor(unlist(strsplit(as.character(tab$ID.MUESTRA),"_pl"))[seq(from=2,to=length(unlist(strsplit(as.character(tab$ID.MUESTRA),"_pl"))),by=2)])
  batch <- as.factor(tab$Batch)
}


aux<-data.frame(tab$Date,tab$Time)
aux$tab.HORA<-as.character(aux$tab.Time)
aux$tab.FECHA<-as.character(aux$tab.Date)
y<-as.POSIXct(paste(aux$tab.Date, aux$tab.Time), format="%m/%d/%y %H:%M")
time <- as.numeric(y-y[1])/(24*60*60)
column<-as.numeric(tab$Column)

    
    
    
cat("Done",fill=TRUE)

}
data_all <- vector("list",length=length(files))
eic_all<- vector("list",length=length(files))
tic_all<- vector("list",length=length(files))
cat("Extraction of the Total Ion Chromatograms initiated...")
cat('\n % done: ')
 lp <- -1




for(i in c(1:length(files))){
  if(is.null(scanRange)){
  data_all[[i]] <- xcmsRaw(files[i])
  #scanRange <- data_all[[i]]@scantime[1]
}else{
    data_all[[i]] <- xcmsRaw(files[i],scanrange=scanRange)
  }
  eic_all[[i]] <- getEIC(data_all[[i]],rtrange=matrix(c(data_all[[i]]@scantime[1],data_all[[i]]@scantime[length(data_all[[i]]@scantime)]),nrow=1),mzrange=matrix(data_all[[i]]@mzrange,nrow=1))
  tic_all[[i]]<- plotTIC(data_all[[i]])
  if(i==1){dataMatrix_all_tic<- matrix(nrow=nrow(tic_all[[i]]),ncol=length(files))}


           perc <-round(which(files[i]==files)/length(files)*100)

  
           if ((perc %% 10 == 0) && (perc != lp)) { cat(perc,' '); lp <- perc }

#  dataMatrix_all_tic[,i] <- as.matrix(tic_all[[i]][,2],ncol=1)
  if(i==1){
    dataMatrix_all_tic[,i] <- as.matrix(tic_all[[i]][,2],ncol=1)
    }else{        
  dataMatrix_all_tic[,i] <- aspline(x=tic_all[[i]][,1],y=tic_all[[i]][,2],xout=tic_all[[1]][,1])$y
}
  }
scanRange <- data_all[[i]]@scantime[1]
 cat("Extraction of the Total Ion Chromatograms Finished",fill=TRUE)
rts <- eic_all[[1]]@eic[[1]][[1]][,1]/60
rownames(dataMatrix_all_tic) <- round(rts,3)
if(is.null(colNames)){
#colnames(dataMatrix_all_tic) <- unlist(strsplit(fileNames,paste(".",fileType,sep="")))
  if(exists("fileNamesOrd")){
colnames(dataMatrix_all_tic) <- fileNamesOrd
}else{
  s<-function(x){return(x[length(x)])}
fileNames <- sapply(X=strsplit(files,"/"),FUN=s)
  colnames(dataMatrix_all_tic) <- fileNames
}
  
}else{
colnames(dataMatrix_all_tic) <- colNames
}
  
}else{

if(is(data,"xcmsSet")){

dataMatrix_all_tic <- as.matrix(peakTable(data)[,(8+length(unique(classes))):dim(peakTable(data))[2]])
rownames(dataMatrix_all_tic) <- peakTable(data)[,1]
output@rawInfo@featureType <- "mass"

#output@rawInfo@scanRange <- c(min(as.numeric(rownames(dataMatrix_all_tic))),max(as.numeric(rownames(dataMatrix_all_tic))))

}else{



  
cat("The data matrix provided includes peak masses or not? (please answer yes or no)")
dataLabel<-scan(n=1,what="character")
if(!dataLabel=="yes"&!dataLabel=="no"){stop("Please answer yes or no")}
dataMatrix_all_tic <- data

#output@rawInfo@scanRange <- try(c(min(as.numeric(rownames(dataMatrix_all_tic))),max(as.numeric(rownames(dataMatrix_all_tic)))))
if(!is.null(dataDir)&is.null(classes)&is.null(tabName)){
  classes <- unlist(strsplit(list.files(dataDir,recursive=T),"/"))[seq(from=1,to=length(unlist(strsplit(list.files(dataDir,recursive=T),"/"))),by=2)]
classLabels <- unique(classes)
}
}
}

if(removeOutliers){
  dataMatrix_all_tic_noOut <- dataMatrix_all_tic
output@rawInfo@outliers<-vector("list",length=length(classLabels))
  names(output@rawInfo@outliers)<-classLabels
  cat("Starting the class-wise outlier detection...",fill=TRUE)
  for(i in c(1:length(classLabels))){
    cat(paste("Outlier detection for class",classLabels[i],"in progress...",sep=" "),fill=TRUE)
 #   if(length(which(classes==classLabels[i]))>10){
    aux <- outlierHotelling(Data=t(dataMatrix_all_tic_noOut[,which(classes==classLabels[i])]),peakInSamples=peakInSamples,automaticOutlierRemoval=automaticOutlierRemoval)
 # }else{
    #aux <- outlierHotelling(Data=t(dataMatrix_all_tic_noOut[,which(classes==classLabels[i])]),PCnumber=length(which(classes==classLabels[i])))
   # aux <- outlierHotelling(Data=t(dataMatrix_all_tic_noOut[,which(classes==classLabels[i])]),PCnumber=length(which(classes==classLabels[i]))-1)
  #    }
    if(length(aux$outlierIndex)!=0){
    dataMatrix_all_tic_noOut<-dataMatrix_all_tic_noOut[,-which(classes==classLabels[i])[aux$outlierIndex]]
    column <- column[-which(classes==classLabels[i])[aux$outlierIndex]]
    time <- time[-which(classes==classLabels[i])[aux$outlierIndex]]
    batch <- batch[-which(classes==classLabels[i])[aux$outlierIndex]]
    classes <- classes[-which(classes==classLabels[i])[aux$outlierIndex]]
    output@rawInfo@outliers[[i]] <- aux$outlierIndex
  }
    cat(paste("Outlier Removal for class",classLabels[i],"done",sep=" "),fill=TRUE)
    cat(fill=TRUE)
  }
  output@rawInfo@data <- dataMatrix_all_tic_noOut
  cat(paste("Outlier Removal stage",classLabels[i],"finished!",sep=" "),fill=TRUE)
}

if(!is.null(dataDir)&!is(data,"xcmsSet")){output@rawInfo@rawDir <- dataDir}else{if(dataLabel=="yes"){output@rawInfo@featureType <- "mass"}else{output@rawInfo@featureType <- "time"}
}
if(!exists("dataLabel")){output@rawInfo@featureType <- "time"}

output@rawInfo@rawData <- dataMatrix_all_tic
output@rawInfo@classes <- classes
#output@rawInfo@scanRange <- scanRange

output@rawInfo@scanRange <- try(as.numeric(c(min(as.numeric(rownames(dataMatrix_all_tic))),max(as.numeric(rownames(dataMatrix_all_tic))))))
if(!is.null(tabName)){output@rawInfo@DOE <- paste(getwd(),tabName,sep="/")}
if(!is.null(time)){output@rawInfo@time <- time}
if(!is.null(column)){output@rawInfo@column <- column}
if(!is.null(batch)){output@rawInfo@batch <- batch}

s<-function(x){return(x[length(x)])}
return(output)
}
