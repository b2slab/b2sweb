outlierHotelling<-function(Data,
			   referenceVector=NULL,
			   PCnumber=10,
                           peakInSamples=0.5,
                           automaticOutlierRemoval=FALSE){


if (dim(Data)[1]<PCnumber){
PCnumber <- dim(Data)[1]
}

#Outlier removal in training data

cat("Outlier removal in drift training data in progress...",fill=TRUE)								



Data <- Data[,apply(Data,2,is.zero)<=peakInSamples]

#res <- pcaCV(Data,amax=10)


X.rob <- scale(Data, center = apply(Data, 2, median),scale = apply(Data, 2, mad))


X.grid <- PCAgrid(X.rob,k=PCnumber,method="mad")

res1 <- PCdiagplot(x=X.rob,PCobj=X.grid,ksel=PCnumber)
#dev.new()

#if(!is.null(referenceVector)){
#	scoreplot(X.grid,col=referenceVector)
#}
								
scoreOutIndex<-which(res1$SDist>=max(res1$critSD))
orthogonalOutIndex<-which(res1$ODist>=max(res1$critOD))								

if(automaticOutlierRemoval){

  index <- scoreOutIndex[scoreOutIndex%in%orthogonalOutIndex]
noOutlierData<-Data
outlierIndex<-vector()
  
}else{

cat("Possible score Outliers:",scoreOutIndex,sep=" ",fill=TRUE)
cat("Possible orthogonal Outliers:",orthogonalOutIndex,sep=" ",fill=TRUE)

noOutlierData<-Data
outlierIndex<-vector()	


#index<-scan(what=numeric(),n=round(length(rownames(annotatedData$xsaFA@xcmsSet@phenoData))%*%0.5))
cat("",fill=TRUE)							
cat("Select sample ID number to be removed",fill=TRUE)

index<-scan(what=numeric(),n=10)

}

while(length(index)!=0){
	
	outlierIndex<-c(outlierIndex,index)
	
#Removing samples
	noOutlierData<-noOutlierData[-index,]
	
#Removing no-expressed Data
	noOutlierData <- noOutlierData[,apply(noOutlierData,2,is.zero)<=peakInSamples]
	
#Robustly scaling data	
	
	X.rob <- scale(noOutlierData, center = apply(noOutlierData, 2, median),
				   scale = apply(noOutlierData, 2, mad))
	
#Building PCA model using k principal components

        if (dim(noOutlierData)[1]<PCnumber){
PCnumber <- dim(noOutlierData)[1]
}


	X.grid <- PCAgrid(X.rob,k=PCnumber,method="mad")
	
	res1 <- PCdiagplot(x=X.rob,PCobj=X.grid,ksel=PCnumber)
	#dev.new()
	
	if(!is.null(referenceVector)){
		
		referenceVector<-referenceVector[-index]
		#scoreplot(X.grid,col=referenceVector)
		
	}
	
scoreOutIndex<-which(res1$SDist>=max(res1$critSD))
orthogonalOutIndex<-which(res1$ODist>=max(res1$critOD))								
	
if(automaticOutlierRemoval){

  index <- scoreOutIndex[scoreOutIndex%in%orthogonalOutIndex]

}else{

        
	cat("Possible score Outliers:",scoreOutIndex,sep=" ",fill=TRUE)
	cat("Possible orthogonal Outliers:",orthogonalOutIndex,sep=" ",fill=TRUE)
	cat("",fill=TRUE)

	cat("Select extra sample ID number to be removed",fill=TRUE)
	index<-scan(what=numeric(),n=10)
        
      }
	
}	
	
cat("Outlier removal finished",sep=" ",fill=TRUE)	



if (!is.null(referenceVector)){
	
	if (length(outlierIndex)>0){
		
		plotModel<-pca(Data[-outlierIndex,],method="svd",nPcs=2,scale="uv")
		#dev.new()
		#scoreplot(plotModel,col=referenceVector)
                plot(scores(plotModel)[,1],scores(plotModel)[,2],xlab="PC1",ylab="PC2",col=referenceVector,pch=16)
                legend("topright",cex=0.5,legend=unique(referenceVector),col=unique(referenceVector),pch=16)

		
		
	}else{
		
		plotModel<-pca(Data,method="svd",nPcs=2,scale="uv")
		#dev.new()
		#scoreplot(plotModel,col=referenceVector)

		
	}
	
}
							
out<-list(noOutlierData,outlierIndex,referenceVector)
names(out)<-c("Data","outlierIndex","batch")

return(out)
}


is.zero <- function(vector){
	
	return(sum(vector==0)/length(vector))
}

