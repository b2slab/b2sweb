correction<-function(normInt,plot=TRUE,printCDF=FALSE,dir2print="correctedCDFs"){
  if(length(normInt@rawInfo@outliers)!=0){
data <- normInt@rawInfo@data
}else{
  data <- normInt@rawInfo@rawData
}
  if(normInt@corrInfo@log==TRUE){
  dat <- scale(log10(t(data+1)),center=TRUE,scale=TRUE)
}else{
  dat <- scale(t(data),center=TRUE,scale=TRUE)
}

cat("Correcting Intensity Drift...")
  
  if(normInt@corrInfo@corrMethod=="cpca"){    
Xc <- dat-((dat %*% normInt@corrInfo@corrModel)%*%t(normInt@corrInfo@corrModel))
   XcRes <- Xc
   for (i in c(1:dim(dat)[2])){
      XcRes[,i] <- (Xc[,i]*attributes(dat)$`scaled:scale`[i])+attributes(dat)$`scaled:center`[i]
   }
   Xc <- XcRes

}

  if(normInt@corrInfo@corrMethod=="cc"){    
Xc <- dat-((dat %*% normInt@corrInfo@corrModel)%*%t(normInt@corrInfo@corrModel))
   XcRes <- Xc
   for (i in c(1:dim(dat)[2])){
      XcRes[,i] <- (Xc[,i]*attributes(dat)$`scaled:scale`[i])+attributes(dat)$`scaled:center`[i]
   }
   Xc <- XcRes
}

  
 normInt@corrInfo@corrData<-t(Xc)

if(plot){
  dev.new()
heatmap.2(main="Corrected Signal (log scale)",x=t(normInt@corrInfo@corrData),trace="none",Rowv=FALSE,Colv=FALSE,dendrogram="none",xlab="Retention Time (min)",ylab="Sample",col=rev(grey(0:15/15)))

 } 

normInt@corrInfo@corrData <- 10^normInt@corrInfo@corrData




cat("Done!",fill=TRUE)


#}

  
  if(printCDF){
cat("Printing corrected cdf files...")
if(!is.null(normInt@rawInfo@rawDir)){
cdfFileCreator(dataMatrix=normInt@corrInfo@corrData,dir2print=dir2print,scanRange=normInt@rawInfo@scanRange,dataDir=normInt@rawInfo@rawDir,log=normInt@corrInfo@log)
}else{
cdfFileCreator(dataMatrix=normInt@corrInfo@corrData,dir2print=dir2print,scanRange=normInt@rawInfo@scanRange,dataDir=getwd(),log=normInt@corrInfo@log)
}
cat("Done!")
  }
  
model<-prcomp(log10(t(data+1)),scale=TRUE)
    if(normInt@corrInfo@log==TRUE){
modelCorr<-prcomp(log10((Xc-min(Xc)+1)),scale=TRUE)
}else{
modelCorr<-prcomp(Xc,scale=TRUE)
}

modClasses <- normInt@corrInfo@modClasses
  cat("",fill=TRUE)


  
classes <- normInt@rawInfo@classes


  cat("",fill=TRUE)




  if(length(normInt@rawInfo@outliers)!=0){
data <- normInt@rawInfo@data
}else{
  data <- normInt@rawInfo@rawData
}
Xc<-(normInt@corrInfo@corrData)
  
data <- scale(log10(t(data+1)),center=TRUE,scale=TRUE)
  Xc <- scale(log10(t(Xc+1)),center=TRUE,scale=TRUE)

  cat("",fill=TRUE)


rawMod <- prcomp(data)
corrMod <- prcomp(Xc)
  
  clMeasuresRaw <- clValid(rawMod$x[classes==modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures
clMeasuresCorr <- clValid(corrMod$x[classes==modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures
internRawDunn <- as.numeric(clMeasuresRaw)[2]
internCorrDunn <- as.numeric(clMeasuresCorr)[2]
internRawSilh <- as.numeric(clMeasuresRaw)[3]
internCorrSilh <- as.numeric(clMeasuresCorr)[3]


  internRaw <- as.numeric(clValid(rawMod$x[classes==modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures)[2]
 internCorr <- as.numeric(clValid(corrMod$x[classes==modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures)[2]



  

  normInt@rawInfo@dunn <- internRawDunn
normInt@corrInfo@dunn <- internCorrDunn
normInt@rawInfo@silhouette <- internRawSilh
normInt@corrInfo@silhouette <- internCorrSilh
  
  cat("Computing Clustering indices ... ",fill=TRUE)


  cat("Raw Data",fill=TRUE)
 show(clValid(rawMod$x[classes==modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures)
    cat("Corrected Data",fill=TRUE)
 show(clValid(corrMod$x[classes==modClasses,1:2], 3, clMethods="kmeans",validation="internal")@measures)

  
if(plot){
model<-prcomp(log10(t(normInt@corrInfo@corrData+1)),scale=TRUE)
dev.new()
plot(model$x[,1],model$x[,2],col=as.numeric(as.factor(normInt@rawInfo@classes)),pch=16,cex=0.8,main="Corrected Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Classes")
legend("topright",pch=16,col=1:length(levels(as.factor(normInt@rawInfo@classes))),legend=levels(as.factor(normInt@rawInfo@classes)),bg=grey(0.9))
}

  

  clMeasuresRaw <- clValid(rawMod$x[!classes=="sample",1:2], 3, clMethods="kmeans",validation="internal")@measures
clMeasuresCorr <- clValid(corrMod$x[!classes=="sample",1:2], 3, clMethods="kmeans",validation="internal")@measures
internRawDunn <- as.numeric(clMeasuresRaw)[2]
internCorrDunn <- as.numeric(clMeasuresCorr)[2]
internRawSilh <- as.numeric(clMeasuresRaw)[3]
internCorrSilh <- as.numeric(clMeasuresCorr)[3]


  cat("Raw Clustering index = ",internRaw,fill=TRUE)
  cat("Corrected Clustering index = ",internCorr,fill=TRUE)

normInt@rawInfo@dunn <- internRawDunn
normInt@corrInfo@dunn <- internCorrDunn
normInt@rawInfo@silhouette <- internRawSilh
normInt@corrInfo@silhouette <- internCorrSilh


  
  
  return(normInt)
  
}










