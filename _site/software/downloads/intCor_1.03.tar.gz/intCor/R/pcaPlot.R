pcaPlot<-function(object,scale=TRUE,log=TRUE,type=c("class","time","column","method")){
            if(!((dim(object@rawInfo@rawData)[1]==1)&&(sum(is.na(object@rawInfo@rawData))==1))){
if(length(object@rawInfo@outliers)!=0){
data <- object@rawInfo@data
}else{
  data <- object@rawInfo@rawData
}

  if(log){
model<-prcomp(log10(t(data+1)),scale=scale)
}else{
model<-prcomp(t(data),scale=scale)
}
if(sum(type=="class")>=1){
dev.new()
plot(model$x[,1],model$x[,2],col=as.numeric(as.factor(object@rawInfo@classes)),pch=16,cex=0.8,main="Raw Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Classes")
legend("topright",pch=16,col=1:length(levels(as.factor(object@rawInfo@classes))),legend=levels(as.factor(object@rawInfo@classes)),bg=grey(0.9))
}

if(sum(length(object@rawInfo@time)!=0&type=="time")>=1){
dev.new()
plot(model$x[,1],model$x[,2],col=rev(heat.colors(max(object@rawInfo@time)))[object@rawInfo@time],pch=16,cex=0.8,main="Raw Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Time Difference (Days)")
legend("topright",pch=16,col=rev(heat.colors(max(object@rawInfo@time)))[c(1,max(object@rawInfo@time))],legend=c("Earlier","Later"),bg=grey(0.9))}

if(length(object@rawInfo@column)!=0&length(object@rawInfo@column)!=0&sum(type=="column")>=1){
dev.new()
plot(model$x[,1],model$x[,2],col=as.numeric((object@rawInfo@column)),pch=16,cex=0.8,main="Raw Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Column change")
legend("topright",pch=16,col=levels(as.factor(as.numeric((object@rawInfo@column)))),legend=paste("Column",levels(as.factor(object@rawInfo@column)),sep=" "),bg=grey(0.9))
}

  if(sum(type=="method")>=1&dim(object@corrInfo@corrModel)[2]>1){
if(sum(object@corrInfo@corrMethod=="cpca")==1){

  if(length(object@rawInfo@outliers)!=0){
dataMatrix <- object@rawInfo@data
}else{
  dataMatrix <- object@rawInfo@rawData
}


classes <- object@rawInfo@classes
out <- object@corrInfo@corrModel
  modClasses <- object@corrInfo@modClasses

if(object@corrInfo@log==TRUE){
X <- log10(t(dataMatrix+1)[classes %in% modClasses,])
}else{
X <- t(dataMatrix)[classes %in% modClasses,]
}
Y <- factor(classes[classes %in% modClasses])

X <- scale(X, center = TRUE, scale = TRUE) # See `attributes(X)`

  
  rownames(X) <- NULL
colnames(X) <- NULL

  M <- prcomp(X)
T <- M$x
P <- M$rotation


# 2: Projct eigenvectors in `E` onto the space of `M` model
Et <- t(out) %*% P # `E` in space of model `M`, i.e. scores of `E`

# select just first two CPC
Et <- Et[1:2, ]

#p2 <- qplot(PC1, PC2, data = as.data.frame(T), color = Y) +
#  geom_segment(data = as.data.frame(Et), aes(x = 0, xend = PC1, 
#    y = 0, yend = PC2, color = rownames(Et)), arrow = arrow(length=unit(0.25, "inches")))
#  dev.new()
#plot(p2,main="CPC directions")
}
}
}
            
if(!((dim(object@corrInfo@corrData)[1]==1)&&(sum(is.na(object@corrInfo@corrData))==1))){


  if(log){
model<-prcomp(log10(t(object@corrInfo@corrData-min(object@corrInfo@corrData)+1)),scale=scale)
}else{
model<-prcomp(t(object@corrInfo@corrData),scale=scale)
}
if(sum(type=="class")>=1){
dev.new()
plot(model$x[,1],model$x[,2],col=as.numeric(as.factor(object@rawInfo@classes)),pch=16,cex=0.8,main="Corrected Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Classes")
legend("topright",pch=16,col=1:length(levels(as.factor(object@rawInfo@classes))),legend=levels(as.factor(object@rawInfo@classes)),bg=grey(0.9))
}
if(length(object@rawInfo@time)!=0&sum(type=="time")>=1){
dev.new()
plot(model$x[,1],model$x[,2],col=rev(heat.colors(max(object@rawInfo@time)))[object@rawInfo@time],pch=16,cex=0.8,main="Corrected Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Time Difference (Days)")
legend("topright",pch=16,col=rev(heat.colors(max(object@rawInfo@time)))[c(1,max(object@rawInfo@time))],legend=c("Earlier","Later"),bg=grey(0.9))}
if(length(object@rawInfo@column)!=0&sum(type=="column")>=1){
dev.new()
plot(model$x[,1],model$x[,2],col=as.numeric((object@rawInfo@column)),pch=16,cex=0.8,main="Corrected Data PCA Scoreplot",xlab=paste("PC1 (",round(summary(model)$importance[2,1]*100,1),"%)",sep=""),ylab=paste("PC2 (",round(summary(model)$importance[2,2]*100,1),"%)",sep=""),sub="Column change")
legend("topright",pch=16,col=levels(as.factor(as.numeric((object@rawInfo@column)))),legend=paste("Column",levels(as.factor(object@rawInfo@column)),sep=" "),bg=grey(0.9))
}
}
}

