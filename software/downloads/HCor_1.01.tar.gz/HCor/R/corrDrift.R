corrDrift <- function(chromatogramsMatrix,peakDriftsList){
hyperbFits <- vector("list",length=dim(chromatogramsMatrix)[2])
hyperbCoeffs <- matrix(ncol=2,nrow=length(peakDriftsList$drift[[1]]))
colnames(hyperbCoeffs) <- c("a","b")
lp <- -1
cat("Model Fitting in progress:",fill=TRUE)
for(i in c(1:dim(chromatogramsMatrix)[2])){
hyperbFits[[i]] <- optim(par=c(1,1), fn=squares,sampleIndex=i,drift=peakDriftsList$drift,picMed=peakDriftsList$zoneVal,control=list(maxit=20000),lower=c(-Inf,"0.5"),method="L-BFGS-B")
perc <-round(which(i==c(1:dim(chromatogramsMatrix)[2]))/length(c(1:dim(chromatogramsMatrix)[2]))*100)
hyperbCoeffs[i,1] <- hyperbFits[[i]]$par[1]
hyperbCoeffs[i,2] <- hyperbFits[[i]]$par[2]
if ((perc %% 10 == 0) && (perc != lp)) { cat(paste(perc,"%",sep=""),' '); lp <- perc }
}
               
cat("Model Fitting finished!",fill=TRUE)
cat("Correcting raw chromatograms...",fill=TRUE)
         
#Correcció deriva mostres
dataMatrix_mod<- matrix(ncol=ncol(chromatogramsMatrix),nrow=nrow(chromatogramsMatrix))
rtVals <- as.numeric(rownames(chromatogramsMatrix))
rtCor <- vector("list",length=dim(chromatogramsMatrix)[2])
for(i in c(1:ncol(chromatogramsMatrix))){
a <- hyperbCoeffs[i,1]
b <- hyperbCoeffs[i,2]
rtCor[[i]] <- rtVals-a/(rtVals+b)
#dataMatrix_mod[,i] <- (spline(x=rtCor[[i]]*60,y=tic_all[[i]][,2],xout=rtVals*60))$y
dataMatrix_mod[,i] <- (spline(x=rtCor[[i]]*60,y=chromatogramsMatrix[,i],xout=rtVals*60))$y
}
rownames(dataMatrix_mod) <- rtVals
colnames(dataMatrix_mod) <- colnames(chromatogramsMatrix)

for(i in c(1:dim(dataMatrix_mod)[1])){
  for(j in c(1:dim(dataMatrix_mod)[2])){
    if(dataMatrix_mod[i,j]<0){dataMatrix_mod[i,j] <- 0}
  }
}


cat("Please set the same anchor peaks for the corrected chromatograms...",fill=TRUE)

peaks_mod<- setAnchorPeaks(chromatogramsMatrix=dataMatrix_mod,nAnchorPeaks=3)
#drift_mod<- vector("list",length=length(peaks_mod))
#zoneVal_mod <- vector(length=length(peaks_mod))
#drift_mod<-lapply(FUN=peakDrift,X=peaks_mod,data=dataMatrix_mod,referenceSample=chromatogramsMatrix[,1])
#zoneVal_mod<-unlist(lapply(FUN=median,X=peaks_mod))
cat("Computing New Peak Drifts...",fill=FALSE)
drift_modList <- peakDrifts(anchorPeaks=peaks_mod,chromatogramsMatrix=dataMatrix_mod)
zoneVal_mod <- drift_modList$zoneVal
cat(" Done",fill=TRUE)

cat("Computing drifts and performing correction...",fill=TRUE)
dataMatrix_corr<-dataMatrix_mod
for(i in c(1:length(drift_modList$drift[[1]]))){
rawSum <- 0
corrSum <- 0
for(j in c(1:length(peaks_mod))){
  rawSum <-rawSum+sum(abs(peakDriftsList$drift[[j]][i]))
  corrSum <- corrSum+sum(abs(drift_modList$drift[[j]][i]))
}
#if(rawSum<corrSum){dataMatrix_corr[,i] <- tic_all[[i]][,2]}
if(rawSum<corrSum){dataMatrix_corr[,i] <- chromatogramsMatrix[,i]}
}
cat("Chromatograms correction finished!",fill=TRUE)

return(dataMatrix_corr)
}
