printCDFfile <- function(dataDir,file,scanRange,dataMatrix,dir2print,fileType){
  
  dataDir <- unlist(strsplit(dataDir,"/"))
  files <- list.files(dataDir,recursive=TRUE,full.names=TRUE)
  fileNamesExt <- unlist(strsplit(files,"/"))[seq(from=3,to=length(unlist(strsplit(files,"/"))),by=3)]
  fileNames <- unlist(strsplit(fileNamesExt,paste(".",fileType,sep="")))
  if(length(grep(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],files))==1){
    filePath <- files[grep(file,files)]
#    data <- dataMatrix[,grep(pattern=file,colnames(dataMatrix))]
    data <- dataMatrix[,grep(pattern=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],colnames(dataMatrix))]
}
  if(length(grep(file,files))>1){
    filePath <- files[match(file,unlist(strsplit(colnames(dataMatrix),paste(".",fileType,sep=""))))]
    data <- dataMatrix[,match(file,unlist(strsplit(colnames(dataMatrix),paste(".",fileType,sep=""))))]
  }
#    data <- dataMatrix[,grep(pattern=file,files)]
    scanRange=round(as.numeric(names(data))[c(1,length(data))]*60)
     sampleXcms<-xcmsRaw(filePath,scanrange=scanRange)
     sampleXcms@tic<-data
#     sampleXcms@scantime<-as.numeric(names(dataMatrix))*60

dir <- unlist(strsplit(files[grep(pattern=file,files)],split=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))]))


  
  #   if(is.null(dir2print)){
   #  write.cdf(file=paste(unlist(strsplit(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],".mzXML")),"cdf",sep="."),sampleXcms)
   #}else{
  
    #    if(!file.exists(unlist(strsplit(paste(getwd(),dir2print,paste(strsplit(filePath,".mzXML"),"cdf",sep="."),sep="/"),file))[1])){dir.create(unlist(strsplit(paste(getwd(),dir2print,paste(strsplit(filePath,".mzXML"),"cdf",sep="."),sep="/"),file))[1])}
     #write.cdf(file=paste(getwd(),dir2print,paste(strsplit(filePath,".mzXML"),"cdf",sep="."),sep="/"),sampleXcms)
    # write.cdf(file=paste(getwd(),dir2print,paste(unlist(strsplit(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],".mzXML")),"cdf",sep="."),sep="/"),sampleXcms)
   #}

    #   if(is.null(dir2print)){
#path <- paste(getwd(),dir2print,paste(unlist(strsplit(files[match(x=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],table=fileNames)],".mzXML")),"cdf",sep="."),sep="/")
  path <- paste(getwd(),dir2print,paste(unlist(strsplit(files[grep(pattern=unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],x=paste(fileNames,fileType,sep="."))],paste(".",fileType,sep=""))),"cdf",sep="."),sep="/")
#  if(!file.exists(unlist(strsplit(path,file))[1])){
#    dir.create(unlist(strsplit(path,file))[1])}
  if(!file.exists(unlist(strsplit(path,strsplit(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],fileType)))[1])){
    dir.create(unlist(strsplit(path,strsplit(unlist(strsplit(file,"/"))[length(unlist(strsplit(file,"/")))],fileType)))[1])}
write.cdf(file=path,sampleXcms)

  
   }
