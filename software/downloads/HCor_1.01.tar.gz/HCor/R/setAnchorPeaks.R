setAnchorPeaks <- function(chromatogramsMatrix,nAnchorPeaks){
peaks <- vector("list",length=nAnchorPeaks)
cat("Select the initial and ending points of the anchor peaks",fill=TRUE)
  for(i in c(1:nAnchorPeaks)){
cat(paste("Anchor Peak",i,sep=" "),fill=TRUE)
plot(rowMeans(chromatogramsMatrix)~as.numeric(rownames(chromatogramsMatrix)),type="l",xlab="Retention time",ylab="Intensity",main="Average Chromatogram")
timeLocator<-locator(2)
index2 <-which.min(abs(as.numeric(rownames(chromatogramsMatrix))-timeLocator$x[2]))
index1 <-which.min(abs(as.numeric(rownames(chromatogramsMatrix))-timeLocator$x[1]))
peaks[[i]] <- as.numeric(rownames(chromatogramsMatrix))[sort(index1:index2)]
}
names(peaks) <- paste("AnchorPeak",c(1:nAnchorPeaks),sep="")
return(peaks)
}
