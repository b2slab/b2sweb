peakDrifts <- function(anchorPeaks,chromatogramsMatrix){
drift <- vector("list",length=length(anchorPeaks))
zoneVal <- vector(length=length(anchorPeaks))
drift<-lapply(FUN=peakDrift,X=anchorPeaks,data=chromatogramsMatrix)
zoneVal<-unlist(lapply(FUN=median,X=anchorPeaks))
out <- list(drift,zoneVal)
names(out) <- c("drift","zoneVal")
return(out)
}
