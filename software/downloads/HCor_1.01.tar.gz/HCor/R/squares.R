squares <- function(sampleIndex,x,picMed,drift){
  a <- x[1]
  b <- x[2]
aux <- (drift[[1]][sampleIndex]-(a/(picMed[1]+b)))^2
for (j in c(2:length(drift))){
  aux <- aux+(drift[[j]][sampleIndex]-(a/(picMed[j]+b)))^2
}
  return(aux)
}
