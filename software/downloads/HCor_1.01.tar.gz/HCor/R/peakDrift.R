peakDrift <- function(peak,maxDrift=5,inP=2,enP=2,percRange=NULL,data,referenceSample=NULL){
range <- vector("list",length=dim(data)[2])
drift <- vector(length=dim(data)[2])
if(!is.null(percRange)){
inP <- length(peak)+round(percRange*length(peak))
enP <- length(peak)+round(percRange*length(peak))}
#if(is.null(inP)){inP <- length(peak)+round(percRange*length(peak))}
#if(is.null(enP)){enP <- length(peak)+round(percRange*length(peak))}
#ind0 <- c(((which(rownames(data)%in%peak))[1]-enP):((which(rownames(data)%in%peak))[2]+inP))
ind0 <- (which((rownames(data))%in%peak)[1]-enP):(which(rownames(data)%in%peak)[length(which(rownames(data)%in%peak))]+inP)
range[[1]] <- ind0
auxVec.i <- vector(length=dim(data)[2])
for(i in c(2:dim(data)[2])){
  aux2 <- vector("list",length=maxDrift)
  aux3 <- vector("list",length=maxDrift)
  ccfAdd <- vector("list",length=maxDrift)
  ccfSubs <- vector("list",length=maxDrift)
  aux<-ccf(x=data[ind0,][,i],y=data[ind0,][,1],plot=FALSE)$acf
  optimPos <- TRUE
  optimNeg <- TRUE
  k <- 0
#  range[[i]] <- range[[i-1]]
    range[[i]] <- range[[1]]
  #inP <- range[[i]][1]
  #enP <- range[[i]][2]
  inP <- 5
  enP <- 5
  while(optimPos==TRUE){
   if(k>maxDrift){
     optimPos <- FALSE
   }else{
#    temp <- inP+1
    ind <- c(((which(rownames(data)%in%peak))[1]-enP+k):((which(rownames(data)%in%peak))[2]+inP+k))
    ind2 <- c(((which(rownames(data)%in%peak))[1]-enP-k):((which(rownames(data)%in%peak))[2]+inP-k))
#    ccfAdd[[k+1]] <- ccf(x=data[ind,][,i],y=data[ind0,][,2],plot=FALSE)
 #   ccfSubs[[k+1]] <- ccf(x=data[ind2,][,i],y=data[ind0,][,2],plot=FALSE)
    if(is.null(referenceSample)){
    ccfAdd[[k+1]] <- ccf(x=data[ind,][,i],y=data[ind0,][,1],plot=FALSE)
    ccfSubs[[k+1]] <- ccf(x=data[ind2,][,i],y=data[ind0,][,1],plot=FALSE)    
  }else{
    ccfAdd[[k+1]] <- ccf(x=data[ind,][,i],y=referenceSample[ind0],plot=FALSE)
    ccfSubs[[k+1]] <- ccf(x=data[ind2,][,i],y=referenceSample[ind0],plot=FALSE)
      }
    aux2[[k+1]]<-ccfAdd[[k+1]]$acf
    aux3[[k+1]]<-ccfSubs[[k+1]]$acf    
    #if(max(aux2)<max(aux)){
      #optimPos <- FALSE
    #}else{
    k <- k+1
    #inP <- temp
  #}
  }
 }
  if(length(which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max))))!=0){
    if(which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))>length(aux2)){
      range[[i]] <- range[[i]]-(which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))-length(aux2))
      drift[[i]] <- -(which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))-length(aux2))+1+ccfSubs[[which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))-length(aux2)]]$lag[which.max(ccfSubs[[which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))-length(aux2)]]$acf)]
    }else{
      range[[i]] <- range[[i]]+which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))
      drift[[i]] <- which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))-1+ccfAdd[[which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))]]$lag[which.max(ccfAdd[[which.max(c(lapply(X=aux2,FUN=max),lapply(X=aux3,FUN=max)))]]$acf)]
    }
  }else{
    drift[[i]] <- 0
  }
#cat(paste("Computing peak drift for anchor peak",as.character(i),"done",sep=" "),fill=TRUE);
#cat(paste(round(i/dim(data)[2]*100,2),"%",sep=""),fill=TRUE)
}
delta.rt <- mean(diff(as.numeric(names(data[,1]))))
driftTimes <- drift*delta.rt
return(driftTimes)
}
