files2Matrix <- function(dataDir,scanRange=NULL,colNames=NULL,tabName=NULL,fileType="mzXML"){
  
  dataDir <- unlist(strsplit(dataDir,"/"))
  files <- list.files(dataDir,recursive=TRUE,full.names=TRUE)
  if(!is.null(tabName)){
    cat("Reading input table...",fill=FALSE)
tab <- read.csv2(tabName,sep=",")


s<-function(x){return(x[length(x)])}
fileNames <- sapply(X=strsplit(files,"/"),FUN=s)
tab <- tab[paste(paste(tab[,2],tab[,5],sep="-"),fileType,sep=".")%in%fileNames,]

index <- vector(length=dim(tab)[1])
    
    for (i in c(1:dim(tab)[1])){
    index[i] <- grep(paste(paste(tab[,2],tab[,5],sep="-"),fileType,sep=".")[i],files)
    }

    
files <- files[index]
fileNamesOrd <- sapply(X=strsplit(files,"/"),FUN=s)

classes <- as.character(tab$TIPO.MUESTRA)
if(is.null(tab$BATCH)){
batch <- as.factor(unlist(strsplit(as.character(tab$ID.MUESTRA),"_pl"))[seq(from=2,to=length(unlist(strsplit(as.character(tab$ID.MUESTRA),"_pl"))),by=2)])
}else{
  batch <- as.factor(tab$BATCH)
}


aux<-data.frame(tab$FECHA,tab$HORA)
aux$tab.HORA<-as.character(aux$tab.HORA)
aux$tab.FECHA<-as.character(aux$tab.FECHA)
y<-as.POSIXct(paste(aux$tab.FECHA, aux$tab.HORA), format="%m/%d/%y %H:%M")
tim <- as.numeric(y-y[1])/(24*60*60)
column<-as.numeric(tab$ID.COLUMNA)

    
    
    
cat("Done",fill=TRUE)

}
data_all <- vector("list",length=length(files))
eic_all<- vector("list",length=length(files))
tic_all<- vector("list",length=length(files))
cat("Extraction of the Total Ion Chromatograms initiated...")
cat('\n % done: ')
 lp <- -1




for(i in c(1:length(files))){
  if(is.null(scanRange)){
  data_all[[i]] <- xcmsRaw(files[i])
  #scanRange <- data_all[[i]]@scantime[1]
}else{
    data_all[[i]] <- xcmsRaw(files[i],scanrange=scanRange)
  }
  eic_all[[i]] <- getEIC(data_all[[i]],rtrange=matrix(c(data_all[[i]]@scantime[1],data_all[[i]]@scantime[length(data_all[[i]]@scantime)]),nrow=1),mzrange=matrix(data_all[[i]]@mzrange,nrow=1))
  tic_all[[i]]<- plotTIC(data_all[[i]])
  if(i==1){dataMatrix_all_tic<- matrix(nrow=nrow(tic_all[[i]]),ncol=length(files))}


           perc <-round(which(files[i]==files)/length(files)*100)

  
           if ((perc %% 10 == 0) && (perc != lp)) { cat(perc,' '); lp <- perc }

  dataMatrix_all_tic[,i] <- as.matrix(tic_all[[i]][,2],ncol=1)
  }
scanRange <- data_all[[i]]@scantime[1]
 cat("Extraction of the Total Ion Chromatograms Finished",fill=TRUE)
rts <- eic_all[[1]]@eic[[1]][[1]][,1]/60
rownames(dataMatrix_all_tic) <- round(rts,3)
if(is.null(colNames)){
colnames(dataMatrix_all_tic) <- fileNamesOrd
}else{
colnames(dataMatrix_all_tic) <- colNames
}

return(dataMatrix_all_tic)
}
