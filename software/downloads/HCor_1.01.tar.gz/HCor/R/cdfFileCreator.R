cdfFileCreator <- function(dataMatrix=NULL,dir2print=NULL,scanRange=NULL,dataDir,fileType="mzXML"){
  if(is.null(dir2print)){stop("No destination directory was set")}
  if(is.null(dataMatrix)){stop("No dataMatrix was set")}
if(!file.exists(paste(getwd(),dir2print,sep="/"))){dir.create(paste(getwd(),dir2print,sep="/"))}
if(!file.exists(paste(getwd(),dir2print,dataDir,sep="/"))){dir.create(paste(getwd(),dir2print,dataDir,sep="/"))}
if(is.null(scanRange)){
  scanRange=as.numeric(rownames(dataMatrix))[c(1,dim(dataMatrix)[1])]
}
#scanrange <- c(1,402)
if(length(grep(fileType,colnames(dataMatrix)))>0){
#files <- paste(unlist(strsplit(colnames(dataMatrix),".mzXML")),"cdf",sep=".")
files <- unlist(strsplit(colnames(dataMatrix),paste(".",fileType,sep="")))
}else{
files <- colnames(dataMatrix)
}
lapply(X=files,dataDir=dataDir,scanRange=scanRange,dataMatrix=dataMatrix,FUN=printCDFfile,dir2print=dir2print,fileType=fileType)
#index<-which(ordFiles%in%file)
#dataMatrix <- dataMatrix[index,]
#for(i in c(1:length(files))){
#printCDFfile(file=files[i],dataDir=dataDir,scanRange=scanRange,dataMatrix=dataMatrix,dir2print=dir2print)
#}
}
