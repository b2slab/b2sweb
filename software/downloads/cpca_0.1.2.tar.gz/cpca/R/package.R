#' Package cpc.
#'
#' Methods to perform Common Principal Component Analysis (CPCA).
#'
#' @rdname cpca-package
#' @name cpca
#' @docType package
#' @example inst/examples/package-cpca.R
{}

